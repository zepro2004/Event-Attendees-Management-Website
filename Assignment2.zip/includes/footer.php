
<footer>
    <div class="container">
        <p>&copy; <?php echo date("Y"); ?> Event Planning System. All rights reserved.</p>
        <ul class="footer-list">
            <li><a href="/Assignment2/html/privacy.html">Privacy Policy</a></li>
            <li><a href="/Assignment2/html/terms.html">Terms of Service</a></li>
            <li><a href="/Assignment2/html/contact.html">Contact Us</a></li>
        </ul>
    </div>
</footer>

</body>
</html>